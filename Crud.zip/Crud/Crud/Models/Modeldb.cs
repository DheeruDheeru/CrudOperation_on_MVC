﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Crud.Models
{
    public class Modeldb
    {
        public int worker_id { get; set; }

        [Display(Name ="First Name")]
        [Required]
        public string first_name { get; set; }

        [Display(Name ="Last Name")]
        [Required]
        public string last_name { get; set; }

        [Display(Name ="salary")]
        [Required]
        public Nullable<int> salary { get; set; }

        [Display(Name ="Date of Joining")]
        [Required]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> doj { get; set; }

        [Display(Name ="Department")]
        [Required]
        public string dept { get; set; }
        public Nullable<int> working_status { get; set; }
    }
}