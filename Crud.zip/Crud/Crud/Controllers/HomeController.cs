﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Crud.Models;
using Crud.DataModel.Operation;

namespace Crud.Controllers
{
    public class HomeController : Controller
    {
        DbOperation userdata = null;
        public HomeController()
        {
            userdata = new DbOperation();
        }

        public ActionResult Index()
        {
            return View();
        }
        // Post: Home
        [HttpPost]
        public ActionResult Index(Modeldb data)
        {
            var usr = userdata.AddUser(data);
            if (ModelState.IsValid)
            {
                ModelState.Clear();
                ViewBag.success = "Record Inserted!!";
            }
            return View();
        }

        public ActionResult GetUsers()
        {
            var data = userdata.GetAll();
            return View(data);
        }
        public ActionResult Detail(int id)
        {
            var getuser = userdata.GetUser(id);
            return View(getuser);
        }

        public ActionResult EditUser(int id)
        {
            var getuser = userdata.GetUser(id);
            return View(getuser);
        }
        [HttpPost]
        public ActionResult EditUser(Modeldb data)
        {
            if (ModelState.IsValid)
            {
                userdata.EditUser(data.worker_id, data);
            }
            return RedirectToAction("GetUsers");
        }

        public ActionResult DltUser(int id)
        {
            var del = userdata.DeleteUser(id);
            return RedirectToAction("GetUsers"); ;
        }
    }
}