﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Crud.Models;

namespace Crud.DataModel.Operation
{
	public class DbOperation
	{
        public int AddUser(Modeldb data)
        {
            using (var add = new DBEntities())
            {
                prac_worker user = new prac_worker()
                {
                    first_name = data.first_name.Trim(),
                    last_name = data.last_name.Trim(),
                    salary = data.salary,
                    doj = data.doj,
                    dept = data.dept.Trim(),
                    working_status = 1
                };
                add.prac_worker.Add(user);
                add.SaveChanges();
                return user.worker_id;
            }    
        }

        public List<Modeldb> GetAll()
        {
            using( var data = new DBEntities())
            {
                var AllUsers = data.prac_worker.Where(x=>x.working_status == 1).Select(x => new Modeldb()
                {
                    worker_id = x.worker_id,
                    first_name = x.first_name,
                    last_name = x.last_name,
                    salary = x.salary,
                    doj =x.doj,
                    dept = x.dept
                }).ToList();

                return AllUsers;
            }
        }

        public Modeldb GetUser(int id)
        {
            using(var data = new DBEntities())
            {
                var SingleUser = data.prac_worker.Where(x=>x.worker_id == id).Select(x=> new Modeldb()
                {
                    worker_id = x.worker_id,
                    first_name = x.first_name,
                    last_name = x.last_name,
                    salary = x.salary,
                    doj = x.doj,
                    dept = x.dept,
                    working_status = x.working_status

                }).FirstOrDefault();

                return SingleUser;
                
            }
        }

        public int EditUser(int id,Modeldb data)
        {
            using (var Edit = new DBEntities())
            {
                var Edituser = Edit.prac_worker.FirstOrDefault(x => x.worker_id == id);
                if (Edituser != null)
                {
                    Edituser.first_name = data.first_name.Trim();
                    Edituser.last_name = data.last_name.Trim();
                    Edituser.salary = data.salary;
                    Edituser.doj = data.doj;
                    Edituser.dept = data.dept.Trim();
                }
                Edit.SaveChanges();
                return Edituser.worker_id;
            }
        }

        public int DeleteUser(int id)
        {
            using (var Del = new DBEntities())
            {
                var DelUser = Del.prac_worker.FirstOrDefault(x => x.worker_id == id);
                if (DelUser!=null)
                {
                    DelUser.working_status = 0;
                    Del.SaveChanges();
                }
                return DelUser.worker_id;
            }
        }

    }
}