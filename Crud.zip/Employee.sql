create table Employee
(
	id int,
	username varchar(25),
	code varchar(20),
	firstName varchar(25),
	middleName varchar(25),
	lastName varchar(25),
	Working_state bit,
	email varchar(25),
	marital_status_id int,
	Designation_id int,
	Department_id int,
	DateOfBirth date,
	DateOfJoining date,
	Gender int,
	PhoneNumber_id int,
	Salary bigint,
	Address_id int,
	PanCard varchar(10),
	Modified_date date,
	BankDetail_id int,
	Company_Id int,
	constraint pk_employee primary key (id),
	constraint DateModified default GETDATE() for Modified_date,
	constraint fk_address foreign key (Address_id) references EmployeeAddress(id),
	constraint fk_Phone foreign key (PhoneNumber_id) references EmployeePhoneNumber(id),
	constraint fk_gender foreign key (gender) references EmployeeGender(id),
	constraint fk_Designation foreign key (Designation_id) references EmployeeDesignation(id), 
	constraint fk_department foreign key (Department_id) references EmployeeDepartment(id),
	constraint fk_maritalstatus foreign key (marital_status_id) references EmployeeMaritalStatus(id),
	constraint fk_bankdetail foreign key (BankDetail_id) references EmployeeBankDetail(id),
	constraint fk_company foreign key (Company_Id) references EmployeeCompany(id)
);

create table EmployeeAddress
(
	id int,
	CurrentAddress varchar(150),
	PermanentAddress varchar(150),
	country_id int,
	constraint pkey_address primary key (id),
	constraint fkey_cntry foreign key (country_id) references country(country_id),
);

create table state_city
(
	city_id int not null,
	city_name varchar(25),
	country_id int,
	state_id int,
	constraint pk_city primary key (city_id),
	constraint fkey_country foreign key (country_id) references country(country_id),
	constraint fk_state foreign key (state_id) references CntryState(state_id)
);

create table CntryState
(
	state_id int not null,
	state_name varchar(25),
	country_id int 
	constraint pkey_state primary key (state_id),
	constraint fk_country foreign key (country_id) references country(country_id)
);

Create table country
(
	country_id int not null,
	country_name varchar(25),
	constraint pk_country primary key (country_id)
);

create table EmployeePhoneNumber
(
	id int,
	PrimaryNumber bigint,
	AlternativeNumer bigint,
	constraint pk_Phone primary key (id)
);

create table EmployeeGender
(
	id int,
	gender varchar(10),
	constraint pk_gender primary key (id)
);

create table EmployeeDesignation
(
	id int,
	DesignationName varchar(25),
	constraint pk_designation primary key (id)
);

create table EmployeeDepartment
(
	id int,
	DepartmentName varchar(30),
	constraint pk_dept primary key (id)
);

create table EmployeeMaritalStatus
(
	id int,
	Marital_status varchar(20),
	constraint pk_maritalstatus primary key (id)
);

create table EmployeeCompany
(
	id int,
	CompanyName varchar(30),
	branch_id int,
	constraint pk_company primary key (id),
	constraint fk_branch foreign key (branch_id) references CompanyBranch(id)
);

create table CompanyBranch
(
	id int,
	branchName varchar(20),
	branchCode varchar(20),
	constraint pk_branch primary key (id)
);

create table EmployeeBankDetail
(
	id int,
	bankName varchar(35),
	AccountHolderName varchar(30),
	AccountNumber bigint,
	IfscCode varchar(11),
	constraint pk_bank primary key (id)
);